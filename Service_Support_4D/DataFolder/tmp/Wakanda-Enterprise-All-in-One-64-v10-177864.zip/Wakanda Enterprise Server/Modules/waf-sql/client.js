/*
 * This file is part of Wakanda software, licensed by 4D under
 *  (i) the GNU General Public License version 3 (GNU GPL v3), or
 *  (ii) the Affero General Public License version 3 (AGPL v3) or
 *  (iii) a commercial license.
 * This file remains the exclusive property of 4D and/or its licensors
 * and is protected by national and international legislations.
 * In any event, Licensee's compliance with the terms and conditions
 * of the applicable license constitutes a prerequisite to any use of this file.
 * Except as otherwise expressly stated in the applicable license,
 * such license does not include any other license or rights on this file,
 * 4D's and/or its licensors' trademarks and/or other proprietary rights.
 * Consequently, no title, copyright or other proprietary rights
 * other than those specified in the applicable license is granted.
 */
var utils = require('./utils');

var Client = function(args) {
        var params = {};
        if (typeof args[0] == 'object') {
			params.dbType = args[0].dbType;
            if (params.dbType === 'mysql') {
                params.hostname = args[0].hostname || 'localhost';
                params.user = args[0].user || 'root';
                params.password = args[0].password || '';
                params.database = args[0].database || '';
                params.port = args[0].port || 3306;
                params.ssl = args[0].ssl || false;
            } else if (params.dbType === 'mssql') {
                params.hostname = args[0].hostname || 'localhost';
                params.user = args[0].user || 'sa';
                params.password = args[0].password || '';
                params.database = args[0].database || '';
                params.port = args[0].port || 1433;
                params.encryptionMode = args[0].encryptionMode || 'not supported';
            } else if (params.dbType === 'odbc') {
                params.dsn = args[0].dsn;
                params.user = args[0].user || '';
                params.password = args[0].password || '';
            } else if (params.dbType === 'oci') {
                params.hostname = args[0].hostname;
                params.user = args[0].user;
                params.password = args[0].password;
                params.servName = args[0].servName;
                params.port = args[0].port;
            } else {
				throw new Error('unsupported database specified with dbType = "' + params.dbType + '".');
			}
        } else {
			params.dbType = args[0];
            if (params.dbType === 'mysql') {
                params.hostname = args[1] || 'localhost';
                params.user = args[2] || 'root';
                params.password = args[3] || '';
                params.database = args[4] || '';
                params.port = args[5] || 3306;
                params.ssl = args[6] || false;
            } else if (params.dbType === 'mssql') {
                params.hostname = args[1] || 'localhost';
                params.user = args[2] || 'sa';
                params.password = args[3] || '';
                params.database = args[4] || '';
                params.port = args[5] || 1433;
                params.encryptionMode = args[6] || 'not supported';
            } else if (params.dbType === 'odbc') {
                params.dsn = args[1];
                params.user = args[2] || '';
                params.password = args[3] || '';
            } else {
				throw new Error('unsupported database specified with dbType = "' + params.dbType + '".');
			}
        }

		if(params.dbType == 'mysql') {
			this._connector = require('waf-private-MYSQ');
		} else if(params.dbType == 'mssql') {
			this._connector = require('waf-private-MSSQ');
		} else if(params.dbType == 'odbc') {
			this._connector = require('waf-private-ODBC');
		} else {
			throw new Error('unsupported database specified with dbType = "' + params.dbType + '".');
		}
        this._impl = this._connector.createSession(params);

        //store the database type if some functions need a different behavior
        this._dbType = params.dbType;
    };

Client.prototype.useDatabase = function(database) {
    var query = 'USE ' + database;
	var res = this.execute(query);
	return res;
};

Client.prototype.execute = function() {
    var query;
    if (arguments.length > 1) {
        query = utils.replacePlaceHolders(arguments);
    } else {
        query = arguments[0];
    }
    this._impl.executeQuery(query);
    var res = new ResultSet();
    res._impl = this._impl.getNextResultSet();
    return res;
};

Client.prototype.hasMoreResults = function() {
	var res = this._impl.hasMoreResultSet();
	return res;
};

Client.prototype.getResultCount = function() {
    var res = this._impl.getResultSetCount();
	return res;
};

Client.prototype.find = function(fields, table, key) {
	key = key || {};
	var row = this._impl.find(fields, table, key);
	return row;
};

Client.prototype.select = function(fields, table, key) {
	key = key || {};
	var res = new ResultSet();
	res._impl = this._impl.select(fields, table, key);
	return res;
};

Client.prototype.update = function(table, fieldsToUpdate, key) {
    key = key || {};
	var res = new ResultSet();
	res._impl = this._impl.update(table, fieldsToUpdate, key);
	return res;
};

Client.prototype.delete = function(table, key) {
    key = key || {};
	var res = new ResultSet();
	res._impl = this._impl.delete(table, key);
	return res;
};

Client.prototype.insert = function(table, values) {
	var res = new ResultSet();
	res._impl = this._impl.insert(table, values);
	return res;
};

Client.prototype.getCount = function(table) {
	var count = this._impl.getCount(table);
	return count;
};

Client.prototype.close = function() {
    this._impl.close();
};

Client.prototype.getNextResult = function() {
    var res, impl;
    impl = this._impl.getNextResultSet();

    if (impl == null) {
        res = null;
    } else {
        res = new ResultSet();
        res._impl = impl;
    }

    return res;
};

Client.prototype.createPreparedStatement = function(query) {
    var stmt, pStmt, impl;

    stmt = this._impl.createStatement(query);
    impl = stmt.getPreparedStatement();
    if (impl != null) {
        pStmt = new PreparedStatement();
        pStmt._impl = impl;
    } else {
        pStmt = null;
    }

    return pStmt;
};

Client.prototype.createNamedPreparedStatement = function(query) {
    //create a namedPreparedStatement from 'query'
    var parsedQuery, paramsMap = {},
        pStmt, namedPStmt;

    try {
        parsedQuery = utils.parse(query, paramsMap);
        pStmt = this.createPreparedStatement(parsedQuery);
    } catch (e) {
        throw new Error(e.message);
    }
    namedPStmt = new NamedPreparedStatement();
    namedPStmt.preparedStatement = pStmt;
    namedPStmt.paramsMap = paramsMap;
    return namedPStmt;

}

function ResultSet() {}

ResultSet.prototype.getAllRows = function() {
	var rows = this._impl.getAllRows();
	return rows;
};

ResultSet.prototype.getNextRow = function() {
	var nextRow = this._impl.getNextRow();
	return nextRow;
};

ResultSet.prototype.getNextRows = function(count) {
	var nextRows = this._impl.getNextRows(count);
	return nextRows;
};

ResultSet.prototype.skipRows = function(count) {
    this._impl.skipRows(count);
};

ResultSet.prototype.getRowsCount = function() {
	var rowsCount = this._impl.getRowCount();
	return rowsCount;
};

ResultSet.prototype.hasNext = function() {
	var res = !this._impl.isEOF();
	return res;
};

ResultSet.prototype.getColumnName = function(i) {
    var allNames = this._impl.getColumnNames();
	var colName = allNames[i];
	return colName;
};

ResultSet.prototype.getColumnType = function(i) {
    var allTypes = this._impl.getColumnTypes();
	var colType = allTypes[i];
	return colType;
};

ResultSet.prototype.getColumnFlags = function(i) {
    var allFlags = this._impl.getColumnFlags();
	var colFlags = allFlags[i];
	return colFlags;
};

ResultSet.prototype.getColumnsCount = function(i) {
	var count = this._impl.getColumnCount();
	return count;
};

ResultSet.prototype.isSelect = function() {
	var res = this._impl.isSelect();
	return res;
};

ResultSet.prototype.isError = function() {
	var res = this._impl.isError();
	return res;
};

ResultSet.prototype.getAffectedRowCount = function() {
	var count = this._impl.getAffectedRowCount();
	return count;
};

function PreparedStatement() {}

PreparedStatement.prototype.getParameterCount = function() {
	var count = this._impl.getParamCount();
	return count;
};

PreparedStatement.prototype.getColumnCount = function() {
	var count = this._impl.getColumnCount();
	return count;
};

PreparedStatement.prototype.setNthParameter = function(index, value) {
    this._impl.setNthParameter(index, value);
};

PreparedStatement.prototype.setParameters = function(values) {
	var len = values.length;
    for (var i = 0; i < len; ++i) {
        this._impl.setNthParameter(i + 1, values[i]);
    }
};

PreparedStatement.prototype.execute = function() {
    var res = new ResultSet();
    res._impl = this._impl.execute();
    if (res._impl == null) {
        res = null;
    }

    return res;
};

function NamedPreparedStatement() {
    this.paramsMap = {};
    this.preparedStatement = new PreparedStatement();
}

/*
 * return number of parameters in the namedPreparedStatement
 */
NamedPreparedStatement.prototype.getParameterCount = function() {
    var count = 0;
    for (var att in this.paramsMap) {
        if (this.paramsMap.hasOwnProperty(att)) {
            ++count;
        }
    }

    return count;
};

NamedPreparedStatement.prototype.getColumnCount = function() {
	var count = this.preparedStatement.getColumnCount();
	return count;
};

NamedPreparedStatement.prototype.setParameter = function(paramName, value) {
    if (arguments.length == 0) {
        throw new Error('Parameter name & value are missing!');
    }

    if (arguments.length < 2) {
        throw new Error('Parameter value is missing!');
    }

    var paramExist = false;
    for (param in this.paramsMap) {
        if (param == paramName) {
            paramExist = true;
			var len = this.paramsMap[param].length;
			var pstmt = this.preparedStatement;
			var paramMap = this.paramsMap[param];
            for (var i = 0; i < len; i++) {
                pstmt.setNthParameter(paramMap[i], value);
            }
        }
    }
    if (!paramExist) {
        throw new Error('Parameter ' + paramName + ' doesn\'t exist!');
    }
};

NamedPreparedStatement.prototype.setParameters = function(values) {
    if (arguments.length == 0) {
        throw new Error('Parameters name & values are missing!');
    }

    if (typeof values != 'object') {
        throw new Error('Parameters must be an object!');
    }

    if (values == null) {
        throw new Error('Parameters can\'t be null!');
    }

    for (param in values) {
        if (this.paramsMap[param] == undefined) {
            throw new Error('Parameter ' + param + ' doesn\'t exist!');
        }
		
		var len = this.paramsMap[param].length;
		var paramMap = this.paramsMap[param];
        for (var i = 0; i < len; i++) {
            this.preparedStatement.setNthParameter(paramMap[i], values[param]);
        }
    }
};

NamedPreparedStatement.prototype.execute = function() {
	var res = this.preparedStatement.execute();
	return res;
};

exports.Client = Client;