/*
 * This file is part of Wakanda software, licensed by 4D under
 *  (i) the GNU General Public License version 3 (GNU GPL v3), or
 *  (ii) the Affero General Public License version 3 (AGPL v3) or
 *  (iii) a commercial license.
 * This file remains the exclusive property of 4D and/or its licensors
 * and is protected by national and international legislations.
 * In any event, Licensee's compliance with the terms and conditions
 * of the applicable license constitutes a prerequisite to any use of this file.
 * Except as otherwise expressly stated in the applicable license,
 * such license does not include any other license or rights on this file,
 * 4D's and/or its licensors' trademarks and/or other proprietary rights.
 * Consequently, no title, copyright or other proprietary rights
 * other than those specified in the applicable license is granted.
 */

 "use strict";

var utils = require('./utils');

var CODES = {
  LDAP_SUCCESS: 0,
  LDAP_OPERATIONS_ERROR: 1,
  LDAP_PROTOCOL_ERROR: 2,
  LDAP_TIME_LIMIT_EXCEEDED: 3,
  LDAP_SIZE_LIMIT_EXCEEDED: 4,
  LDAP_COMPARE_FALSE: 5,
  LDAP_COMPARE_TRUE: 6,
  LDAP_AUTH_METHOD_NOT_SUPPORTED: 7,
  LDAP_STRONG_AUTH_REQUIRED: 8,
  LDAP_REFERRAL: 10,
  LDAP_ADMIN_LIMIT_EXCEEDED: 11,
  LDAP_UNAVAILABLE_CRITICAL_EXTENSION: 12,
  LDAP_CONFIDENTIALITY_REQUIRED: 13,
  LDAP_SASL_BIND_IN_PROGRESS: 14,
  LDAP_NO_SUCH_ATTRIBUTE: 16,
  LDAP_UNDEFINED_ATTRIBUTE_TYPE: 17,
  LDAP_INAPPROPRIATE_MATCHING: 18,
  LDAP_CONSTRAINT_VIOLATION: 19,
  LDAP_ATTRIBUTE_OR_VALUE_EXISTS: 20,
  LDAP_INVALID_ATTRIBUTE_SYNTAX: 21,
  LDAP_NO_SUCH_OBJECT: 32,
  LDAP_ALIAS_PROBLEM: 33,
  LDAP_INVALID_DN_SYNTAX: 34,
  LDAP_ALIAS_DEREF_PROBLEM: 36,
  LDAP_INAPPROPRIATE_AUTHENTICATION: 48,
  LDAP_INVALID_CREDENTIALS: 49,
  LDAP_INSUFFICIENT_ACCESS_RIGHTS: 50,
  LDAP_BUSY: 51,
  LDAP_UNAVAILABLE: 52,
  LDAP_UNWILLING_TO_PERFORM: 53,
  LDAP_LOOP_DETECT: 54,
  LDAP_NAMING_VIOLATION: 64,
  LDAP_OBJECTCLASS_VIOLATION: 65,
  LDAP_NOT_ALLOWED_ON_NON_LEAF: 66,
  LDAP_NOT_ALLOWED_ON_RDN: 67,
  LDAP_ENTRY_ALREADY_EXISTS: 68,
  LDAP_OBJECTCLASS_MODS_PROHIBITED: 69,
  LDAP_AFFECTS_MULTIPLE_DSAS: 71,
  LDAP_OTHER: 80,
  LDAP_PROXIED_AUTHORIZATION_DENIED: 123
};

var LDAPError = function(errorName, errorCode, msg, dn, caller) {
	if (Error.captureStackTrace) {
		Error.captureStackTrace(this, caller || LDAPError);
	}

	Object.defineProperty(this, "dn", {
		get : function() {
			return dn ? dn : ""
		}
	});

	Object.defineProperty(this, "code", {
		get : function() {
			return errorCode;
		}
	});

	Object.defineProperty(this, "name", {
		get : function() {
			return errorName;
		}
	});

	Object.defineProperty(this, "message", {
		get : function() {
			return msg;
		}
	});

};

//this error must inherits from Error class
utils.inherits(LDAPError, Error);

var ldapErrors = {};

Object.keys(CODES).forEach(function (code) {
	if (code === 'LDAP_SUCCESS') {
		return;
	}

	var codeValue = CODES[code];

	var err = '';
	var msg = '';
	var pieces = code.split('_').slice(1);
	for (var i = 0; i < pieces.length; i++) {
		var lc = pieces[i].toLowerCase();
		var key = lc.charAt(0).toUpperCase() + lc.slice(1);
		err += key;
		msg += key + ((i + 1) < pieces.length ? ' ' : '');
	}

	if (!/\w+Error$/.test(err)) {
		err += 'Error';
	}

	// At this point LDAP_OPERATIONS_ERROR is now OperationsError in $err
	// and 'Operations Error' in $msg

	ldapErrors[codeValue] = function (message, dn, caller) {
		LDAPError.call(this,
			err,
			CODES[code],
			message || msg,
			dn || null,
			caller || exports[err]);
	};

	ldapErrors[codeValue].constructor = ldapErrors[codeValue];

	utils.inherits(ldapErrors[codeValue], LDAPError);
});

exports.createLDAPErrorFrom = function(err) {
	var ldapErrMsg, ldapErrCode, ldapErrDN;
	
	var data = err.message.split('|');
	
	var len = data.length;
	
	if(len >= 1)
		ldapErrMsg = data[0].trim();
	else
		ldapErrMsg = "";
	
	if(len >= 2)
		ldapErrCode = parseInt(data[1]);
	else
		ldapErrCode = -1;
		
	if(len >= 3)
		ldapErrDN = data[2].trim();
	else
		ldapErrDN = "";

	//parse this error
	//if this err dosen't have an error code or the error code
	//dosen't exist in the codes this is other ldap error
	if(!ldapErrors.hasOwnProperty(ldapErrCode)) {
		ldapErrCode = 80;
	}

	//returns the appropriate error
	return new ldapErrors[ldapErrCode](ldapErrMsg, ldapErrDN);
};
