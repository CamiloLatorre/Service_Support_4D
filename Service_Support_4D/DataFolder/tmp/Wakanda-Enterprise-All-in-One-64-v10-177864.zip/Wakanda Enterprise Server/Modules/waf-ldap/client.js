/*
 * This file is part of Wakanda software, licensed by 4D under
 *  (i) the GNU General Public License version 3 (GNU GPL v3), or
 *  (ii) the Affero General Public License version 3 (AGPL v3) or
 *  (iii) a commercial license.
 * This file remains the exclusive property of 4D and/or its licensors
 * and is protected by national and international legislations.
 * In any event, Licensee's compliance with the terms and conditions
 * of the applicable license constitutes a prerequisite to any use of this file.
 * Except as otherwise expressly stated in the applicable license,
 * such license does not include any other license or rights on this file,
 * 4D's and/or its licensors' trademarks and/or other proprietary rights.
 * Consequently, no title, copyright or other proprietary rights
 * other than those specified in the applicable license is granted.
 */

"use strict";

var ldapComponent = require('waf-private-LDAP');
var User = require('./user').User;
var errors = require('./errors');

/*
** As all user functions use at the end the client functions
** error handling will be only done here
*/

/*
 *	Client constructor
 *	@abstract: create an ldap client 
 *	@params: an object that has the following properties:
 *				- hostname
 *				- port
 *				- uuidAttribute (default "objectGUID")
 *				i.e : {
 *					hostname : "192.168.2.22",
 *					port : 389,
 *					uuidAttribute : "entryUUID"
 *				}
 *			or :
 *				- url
 *				- uuidAttribute (default "objectGUID")
 *				i.e : {
 *					url : "ldap://192.168.2.22:389"
 *					uuidAttribute : "entryUUID"
 *				}
 */
 
var Client = function(params) {
	try {
		this._impl = ldapComponent.createClient(params);
		//the bind user is null
		this.user = null;
		
		//store params
		this.params = params;		
	} catch(err) {
		var ldapErr = errors.createLDAPErrorFrom(err);
		throw ldapErr;
	}
};

/*
 *	bind function
 *	@abstract : bind the current client using the given distinguished
 *				name and the given password
 *	@params:
 *		- dn : 			the distinguished name
 *		- password : 	the password for bind
 */
Client.prototype.bind = function(dn, password) {
	password = password || "";
	try {
		this._impl.bind(dn, password);
		this.user = new User(this, dn);
	} catch(err) {
		var ldapErr = errors.createLDAPErrorFrom(err);
		throw ldapErr;
	}
};

/*
* 	unbind function
* 	@abstract : unbind the client
* 	@params:
* 		- none
*/	
Client.prototype.unbind = function() {
	if(this.user !== null) {
		try {
			this._impl.unbind();
			this.user = null;
		} catch(err) {
			var ldapErr = errors.createLDAPErrorFrom(err);
			throw ldapErr;
		}
	}
};

/*
 *	 search function
 *	 abstract: search all entries that match the given filter from the given distinguished
 *		name with the given scope
 *	 @params:
 *	 	- dn : the distinguished name
 *		- search params as object
 *		{
 *		filter : search filter as a string
 *		scope : search scope (for the moment only "base" and "sub" are valid)
 *		attributes : the attributes to retrieve from the matched entries
 *		}
 *	 @return:
 *			array of objects that has as properties the given attributes and as an attribute can be
 *	 		founded multiple times in one entry the value of an attributes is an array of values
 */
Client.prototype.search = function (dn, searchParams) {
	searchParams = searchParams || {};
	var filter = searchParams.filter || "";
	var scope = searchParams.scope || "base";
	var attributes = searchParams.attributes || [];
	var entries,result=[],len;
	
	try {
		entries = this._impl.search(dn, filter, scope, attributes);
	} catch(err) {
		var ldapErr = errors.createLDAPErrorFrom(err);
		throw ldapErr;
	}
	len = entries.length;
	for  ( var i = 0 ; i< len; ++i )
	{
		var oneResult = {};
		for ( var attr in entries[i] ){
			if (  entries[i][attr].length == 1 )
			{
				oneResult[attr] = entries[i][attr][0];
			}
			else
			{
				oneResult[attr] = entries[i][attr];
			}
			
		}
		
		result.push(oneResult);
	}
	return result;
};

/*
* 	compare function
* 	@abstract : compare for the an entry identified by its DN if the attribute value match the given value
* 	@params:
* 		- dn : the distinguished name of the entry
*		- attribute : the attribute name
*		- value : the value to compare with
*	@return:
*		- true if the value match the attribute value false else
*/
Client.prototype.compare = function(dn, attribute, value) {
	var res;

	try {
		res = this._impl.compare(dn, attribute, value);
	} catch(err) {
		var ldapErr = errors.createLDAPErrorFrom(err);
		throw ldapErr;
	}

	return res;
};

/*
*	getUser function
*	@abstract : get the user defined by the given distinguished name
*	@params :
*		- dn : the distinguished name
*	@return:
*		- the user with distinguished name dn
*/

Client.prototype.getUser = function(dn) {
	var user = new User(this, dn);
	return user;
};

exports.Client = Client;
