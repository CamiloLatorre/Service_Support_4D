/*
 * This file is part of Wakanda software, licensed by 4D under
 *  (i) the GNU General Public License version 3 (GNU GPL v3), or
 *  (ii) the Affero General Public License version 3 (AGPL v3) or
 *  (iii) a commercial license.
 * This file remains the exclusive property of 4D and/or its licensors
 * and is protected by national and international legislations.
 * In any event, Licensee's compliance with the terms and conditions
 * of the applicable license constitutes a prerequisite to any use of this file.
 * Except as otherwise expressly stated in the applicable license,
 * such license does not include any other license or rights on this file,
 * 4D's and/or its licensors' trademarks and/or other proprietary rights.
 * Consequently, no title, copyright or other proprietary rights
 * other than those specified in the applicable license is granted.
 */

 "use strict";

var User = function (client, dn) {
	//define dn and client as read only property
	Object.defineProperty(this, "dn", {
		value : dn,
		writable: false
	});

	Object.defineProperty(this, "client", {
		value : client,
		writable: false
	});

	//store uuid and groups if already retrieved
	this.uuid = null;
	this.groups = null;
};

/*
 *	getUUID function
 *	abstract: get the user uuid
 *	@params: none
 */
User.prototype.getUUID = function () {
	if(this.uuid === null) {
		var attribute = this.client.params.uuidAttribute;
		var entries = this.client.search(this.dn, {
			attributes : [attribute]
		});

		if(entries.length == 1) {
			var entry = entries[0];
			if(entry.hasOwnProperty(attribute)) {
			  if ( entry[attribute] instanceof  Array )
				this.uuid = entry[attribute][0];
			  else
				this.uuid = entry[attribute];
			}
		}
	}

	return this.uuid;
};

/*
 *	getGroups function
 *	abstract: get the user groups
 *	@params: none
 */
User.prototype.getGroups = function () {
	if(this.groups === null) {
		var entries = this.client.search(this.dn, {
			attributes : ["memberOf"]
		});

		var groups = [];

		if(entries.length == 1) {
			var entry = entries[0];
			if(entry.hasOwnProperty("memberOf")) {
				var groupDNs=[];
				if ( entry.memberOf instanceof Array )
				{
					groupDNs = entry.memberOf;
				}else
				{
					groupDNs.push(entry.memberOf);
				}
				groupDNs.forEach(function(groupDN) {
					var a = groupDN.split(',');
					var g = {};
					a.forEach(function(f) {
						var x = f.split("=");
						var dnStr = x[0];
						var dnValue = x[1];
						if(!g.hasOwnProperty(dnStr)) {
							g[dnStr] = [];
						}
						g[dnStr].push(dnValue);
					});

					groups.push(g);
				});
			}
		}

		this.groups = groups;
	}

	return this.groups;
};

exports.User = User;
