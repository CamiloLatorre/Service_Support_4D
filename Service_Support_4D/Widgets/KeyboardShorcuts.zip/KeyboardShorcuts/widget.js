WAF.define('KeyboardShorcuts', ['waf-core/widget'], function(widget) {
	
    var KeyboardShorcuts = widget.create('KeyboardShorcuts', {
        init: function() {
//            /* Define a custom event */
            this.fire('myEvent', {
                message: 'Functions events keyShorts'
            });
        }
    });
    
     KeyboardShorcuts.addProperty('attributes', {
        	type: "list",
        	attributes: [{
		        name: 'KeyShort'
		    }],
            onChange: function(newValue) {
                this.node.innerHTML = this.test(); /* this contains the widget and newValue contains its current value */
            }
     })

//    /* Map the custom event above to the DOM click event */
    KeyboardShorcuts.mapDomEvents({
        'click': 'action'
    });

    return KeyboardShorcuts;

});

/* For more information, refer to http://doc.wakanda.org/Wakanda0.DevBranch/help/Title/en/page3871.html */