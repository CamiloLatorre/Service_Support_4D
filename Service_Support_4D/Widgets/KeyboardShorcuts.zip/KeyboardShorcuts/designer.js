(function(KeyboardShorcuts) {
	
//    /* Default width and height of your widget */
	KeyboardShorcuts.setCategory('Action Events');
	KeyboardShorcuts.setIcon('/icons/widget.png');
	KeyboardShorcuts.setDescription('Keyboard Shortcut');
	
//	KeyboardShorcuts.addEvents([{
//	    'name':'load',
//	    'description':'On Load',
//	    'category':'Load Events'
//	}]);
	
//	KeyboardShorcuts.on('display', function(attributes) {
//    	
//		var valAttributes = attributes['data-keyboardKeys'];
//    	if(valAttributes) { 
//			for(var i = 0; i < valAttributes.lenght; i++){
//				$('#' + this.id).html('['+valAttributes[i]+']');
//			}
//		}
//    });

    
//    KeyboardShorcuts.setWidth('200');
//    KeyboardShorcuts.setHeight('20');

//    /* Define custom event for your widget */
//    KeyboardShorcuts.addEvent('myEvent');

//    /* Customize existing properties */
//    KeyboardShorcuts.customizeProperty('test', {
//        sourceTitle: 'Test Source',
//        title: 'Test Static Value',
//        description: 'Add a datasource to this property.'
//    });

//    /* Add a Label property */
//    KeyboardShorcuts.addLabel({
//        'defaultValue': '',
//        'position': 'top'
//    });

//    /* Set the Design and Styles panels */
//    KeyboardShorcuts.setPanelStyle({
//        'fClass': true,
//        'text': true,
//        'background': true,
//        'border': true,
//        'sizePosition': true,
//        'label': true,
//        'disabled': ['border-radius']
//    });

//    /* Override widget's initialization */
//    KeyboardShorcuts.prototype.init = function() {
//        this.node.innerHTML = "Widget Text"; /* Include text inside the widget */
//    }

});

// For more information, refer to http://doc.wakanda.org/Wakanda0.DevBranch/help/Title/en/page3870.html