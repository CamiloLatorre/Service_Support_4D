(function() {
    var LoginSesion = Widget.LoginSesion.inherit(WAF.require('waf-behavior/studio'));
    
      /*Display name of the widget*/
	//LoginSesion.setCategory('Action Events');
	//LoginSesion.setIcon('/icons/widget.png');
	LoginSesion.setDescription('Login Sesion');

      /*Define your widget's properties*/
	LoginSesion.addAttributes([{
	         name        : 'data-keyboardKeys',              
	         description : 'Shortcut keys',
			 type        : 'grid',
			 columns	 : [
				{
					name: 'data-Key',
					KeyboardKey: 'Keyboard Key',
					type: 'textField'
				}
			]
	}]);

      /*Define the events for your widget*/
	LoginSesion.addEvents([{
	    'name':'click',
	    'description':'On Click',
	    'category':'Mouse Events'
	},
	{
		'name':'blur',
	    'description':'On Blur',
	    'category':'Focus Events'
	}]);
	
	LoginSesion.on('display', function(attributes) {
    	
		var valAttributes = attributes['data-keyboardKeys'];
    	if(valAttributes) { 
			for(var i = 0; i < valAttributes.lenght; i++){
				$('#' + this.id).html('['+valAttributes[i]+']');
			}
		}
    });
		
	LoginSesion.makeBindableProperty(LoginSesion.prototype.value);
})();