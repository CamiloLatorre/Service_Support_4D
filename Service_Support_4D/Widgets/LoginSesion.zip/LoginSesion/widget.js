(function() {
    var widget = WAF.require('waf-core/widget');
	var LoginSesion = widget.create('LoginSesion');
	var keyboardkeys;
	
    LoginSesion.inherit(WAF.require('waf-behavior/layout/container'));
	LoginSesion.inherit(WAF.require('waf-behavior/focus'));
	
	Event.create("click"); //declare the event
	LoginSesion.autoFireDomEvent('click', Event.click);

	Event.create("blur"); //declare the event
	LoginSesion.autoFireDomEvent('blur', Event.blur);
	
	LoginSesion.prototype.init = function(){
		var valAttributes = "";
		valAttributes = this.options.keyboardkeys;
		
		keyboardkeys = new Array();
		if(valAttributes != undefined){
			var valKeys = valAttributes.split(",");
			valKeys[0] = valKeys[0].substr(1);

			for(var i = 0; i < valKeys.length; i++){
				var key = valKeys[i].substr(13);
					
				var pos = key.search("'");
				key = key.slice(0, pos);
				
				keyboardkeys[i]= key;
				
			}
		}
		
	};
	
	LoginSesion.prototype.setActions = function( actions ){
		for(var i = 0; i < keyboardkeys.length; i++){
			shortcut.add(keyboardkeys[i], actions[i]);
		}
	}
	
	LoginSesion.prototype.removeActions = function(){
		for(var i = 0; i < keyboardkeys.length; i++){
			shortcut.remove(keyboardkeys[i]);
		}
	}
})();
